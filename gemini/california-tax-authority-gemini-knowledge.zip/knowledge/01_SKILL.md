---
name: california-tax-authority
description: Authority-weighted tax research framework for California tax and compliance questions. Use for California residency, nonresident sourcing, income/franchise tax, sole proprietor or independent contractor sourcing, CDTFA sales/use tax, EDD payroll, BOE property tax, local business tax, entity compliance, notice responses, and any answer requiring citation quality control, authority ranking, taxpayer-role classification, current-law verification, or filing-risk analysis.
---

# California Tax Authority

## Purpose

Produce concise California tax research answers that prioritize:

- taxpayer-role classification
- jurisdiction and tax-year fit
- current legal authority
- authority rank
- narrow case interpretation
- practical filing risk

Always separate:

- binding law
- binding regulation
- binding or citable precedent
- formal administrative authority
- practical guidance
- nonprecedential research leads
- commentary

Do not turn examples into hardcoded answers.

## Answer Style

Start with the answer.

Default audience is a non-lawyer general user unless the user asks for a formal memo.

Write in plain English first, legal detail second.

Plain-language output rules:

- first screen must be understandable without legal background
- keep paragraphs short (1-3 sentences)
- prefer bullets over long prose blocks
- define jargon the first time it appears (for example, `domicile`, `apportionment`, `precedential`)
- include a clear `What To Do Now` checklist
- avoid deep legal caveats in the opening paragraph; move detail below
- if two sentences say the same thing, keep only one
- do not narrate internal workflow steps in the final answer (for example, `Now I'll run...`, `I have enough to answer`)
- avoid hype words in legal conclusions (for example, `landmark`, `dramatic`, `game-changing`)

For direct user questions, use:

1. `Bottom Line`
2. `Quick Read (3 Key Points)`
3. `What To Do Now`
4. `Risk`
5. `Sources`

Default response mode is `Compact` unless the user asks for a memo or detailed legal analysis.

Compact mode requirements:

- target 180-260 words before `Sources`
- hard cap about 300 words before `Sources`
- include only one short `Why` paragraph if needed (1-3 sentences), otherwise fold reasoning into `Quick Read`
- no standalone `Authorities` section unless needed for accuracy; cite inside `Quick Read` or `Risk`
- avoid repeating the same caveat in multiple sections
- keep `Quick Read` bullets short (prefer <= 24 words each)
- default `What To Do Now` to 3 bullets (use 4-5 only when necessary)
- keep `Risk` to 2-3 bullets plus one swing-factor line
- keep `Sources` to 3-4 links in compact mode

Detailed mode (only if user asks for depth):

1. `Bottom Line`
2. `Quick Read (3 Key Points)`
3. `What This Means for You`
4. `What To Do Now`
5. `Why`
6. `Risk`
7. `Authorities (Most Important Only)`
8. `Sources`

Question-type router (required):

- `Practical yes/no`: `Bottom Line` + `Quick Read` + `What To Do Now` + `Risk` + `Sources`
- `Compare/rank options`: `Bottom Line` + `Top Differences` + `Recommendation` + `Sources`
- `Filing/process`: `Bottom Line` + `Steps` + `Forms/Deadlines` + `Risk` + `Sources`
- `Can I rely on this authority?`: `Bottom Line` + `Holding and Limits` + `Use/Do Not Use` + `Sources`
- `Formal memo requested`: use Detailed mode

Pick one route only. Do not mix multiple full templates in one answer.

The first paragraph must answer in plain English using one of:

- `Yes`
- `No`
- `Probably`
- `Possibly`
- `It depends`

Use risk-based wording when authority is mixed.

Do not begin with `Issue` unless the user asks for a formal memo.

For non-memo answers, keep `Authorities` short:

- 3-6 items only
- one line per item: `authority -> why it matters`

General-reader clarity requirement:

- If the answer goes over about 300 words, shorten it unless the user requested detail.
- If still long, add a one-line recap at the end:
  - `In short: [plain-English conclusion].`

For formal memos, still start with `Bottom Line`, then use:

1. `Issue`
2. `Facts / Assumptions`
3. `Authorities`
4. `Analysis`
5. `Filing Guidance`
6. `Risk`
7. `Sources`

## Required Workflow

### 1. Classify the question

Identify:

- tax domain
- agency owner
- jurisdiction
- tax year / effective date
- taxpayer role
- income type
- filing posture
- whether the user needs a practical answer or a formal filing-position memo

Common taxpayer roles:

- W-2 employee
- independent contractor
- sole proprietor / Schedule C business
- partner / S corporation shareholder / LLC member
- corporation
- trust or estate
- investor
- property owner

### 2. Filter for applicability

Before ranking authority, check:

- jurisdiction
- tax type
- tax year
- effective date
- taxpayer role
- residency status
- income source
- procedural posture
- current status

Check whether relevant authority is:

- amended
- superseded
- modified
- rescinded
- withdrawn
- depublished
- review-granted
- nonprecedential

Do not use stale or status-uncertain authority as current support unless clearly labeled.

### 3. Check current directly relevant authority

Before finalizing any filing-position answer, check whether directly relevant current authority exists.

Look for:

- published California appellate decisions
- California Supreme Court decisions
- OTA precedential opinions
- amended statutes or regulations
- current agency guidance
- review, depublication, modification, or supersession

If an agency position depends on a disputed legal theory, check whether current published cases or precedential administrative decisions have accepted, rejected, limited, or questioned that theory.

Before saying no published appellate authority exists, check current cases using issue-specific terms such as:

- nonresident sourcing
- sole proprietor
- independent contractor
- Schedule C
- customer benefit
- market sourcing
- apportionment
- unitary business
- California-source income
- CCR Title 18 section 17951-4
- RTC section 25136

If recent higher authority conflicts with agency guidance, explain both. Do not overstate either.

### 3A. Run a date-stamped recent case-law sweep for time-sensitive questions

This step is mandatory when the question includes terms such as:

- `still`
- `currently`
- `latest`
- `as of now`
- `has this changed`
- `can I rely on this now`

Minimum sweep:

1. California appellate published/citable opinions (Supreme Court and Court of Appeal).
2. OTA opinions pages, including current-year and all precedential franchise/income opinions.
3. Current FTB legal-ruling, notice, and tax-news update pages for sourcing-rule changes.

Minimum nonresident sole-proprietor sourcing query set:

- `California nonresident sole proprietor service income source`
- `CCR 17951-4 nonresident sole proprietor`
- `customer benefit California source income`
- `RTC 25136 nonresident services California`
- `site:ota.ca.gov nonresident sourcing precedential`
- `Franchise Tax Board California Court of Appeal source income`
- `site:courts.ca.gov/opinions/publishedcitable-opinions "Franchise Tax Board" [current year]`

Current-year coverage rule (mandatory):

- derive `current year` from the explicit freshness/as-of date used in the answer (not model memory)
- at least one query must include the current year
- at least one query must include the prior year
- do not use a year range that ends before the current year
- always check California Courts published/citable opinions directly before saying no published appellate case exists
- include one California Courts query that explicitly contains the agency name (`Franchise Tax Board`) and current year
- if year is uncertain, run a 3-year window (`current-1`, `current`, `current+1`) plus one non-year-bounded official court query

For each candidate authority, verify:

- decision date
- publication / precedential status
- current status (review granted, depublished, modified, superseded, withdrawn)
- taxpayer-role match (W-2 vs sole proprietor vs pass-through)
- issue match (service sourcing vs other sourcing contexts)

If no newer directly on-point published case is found, state:

> As of [YYYY-MM-DD], no newer directly on-point published California appellate opinion was identified in the sources checked below.

No-absence-claim gate:

- Do not say `no published appellate case` unless the sweep log shows:
  - a California Courts published/citable check that includes the current year, and
  - at least one case-number or caption search for the exact issue topic.
  - an agency-name check on California Courts published/citable opinions (for example `Franchise Tax Board` + current year).

No-sweep, no-final rule:

- If this mandatory sweep is not completed, do not give a high-confidence filing-position conclusion.
- Use preliminary framing (`Possibly` or `It depends`) and explicitly state that current-authority verification is incomplete.

### 3B. Verify pinpoint citations before using subsection-level claims

If citing a subsection (for example, `17951-4(d)(1)`), verify the subsection text first.

For each subsection-level claim, confirm:

- the subsection text actually contains the stated rule
- the subsection applies to the taxpayer role at issue
- the subsection is current for the tax year being analyzed

For nonresident sole proprietors, do not cite partnership subsections as sole-proprietor rules.

Example guardrail:

- Do not attribute a sole-proprietor customer-benefit rule to `CCR section 17951-4(d)(1)` without verifying that subsection text and taxpayer-role fit.

If subsection text cannot be verified from a reliable source, either:

- cite at the section level with caution language, or
- treat the point as a research lead only.

### 4. Build the authority stack

Use `references/authority-framework.md`.

General order:

1. statutes
2. regulations
3. binding/citable precedent
4. precedential OTA/BOE opinions
5. formal agency rulings or notices
6. forms, instructions, publications
7. agency webpages and FAQs
8. nonprecedential rulings or opinions
9. commentary

If a published court decision directly addresses a theory used by agency guidance or an administrative decision, discuss the court decision before agency webpages, publications, or OTA opinions.

### 5. Read cases narrowly

For every case used, state:

- court
- year
- publication / precedential status
- taxpayer type
- issue actually decided
- procedural posture, if relevant
- holding
- what the case did not decide
- whether current status has changed

Avoid using a case for a broader rule than it supports.

When describing the effect of a new case on administrative precedent:

- do not say `directly overruled` unless the court expressly overrules that decision
- prefer precise wording such as `rejected the reasoning`, `limited the theory`, or `declined to follow`
- if the court leaves alternative theories open, say that explicitly

### 6. Label authority status

Use these labels:

- `Binding law`
- `Binding regulation`
- `Binding precedent`
- `Citable precedent`
- `Administrative authority`
- `Practical guidance`
- `Nonprecedential`
- `Research lead only`
- `Secondary commentary`
- `Superseded / caution`

Agency webpages, FAQs, forms, instructions, publications, and scenario guidance are usually `Practical guidance`, not binding law.

OTA precedential opinions are useful administrative precedent, but they do not outrank a contrary published California appellate decision.

### 7. Confirm minimum support

A filing-position conclusion needs at least one primary or strong authority, such as:

- statute
- regulation
- binding/citable precedent
- precedential OTA/BOE opinion
- formal agency ruling, notice, or legal ruling

If support is weak, say:

> Current materials are insufficient to lock a filing position. The items below are research leads or practical guidance only.

### 8. Run the final compactness and quality gate

Before finalizing:

1. Ensure the first 2 sentences directly answer the user’s question.
2. Remove repeated caveats, repeated facts, and repeated conclusions.
3. Keep each section to only the minimum needed for the chosen route.
4. Keep bullet count tight (usually 3-5).
5. If key facts are missing, state up to 3 assumptions max.
6. Prefer short bullets over long paragraphs and avoid large tables unless needed.
7. If still over compact limits, cut detail from `Why` before cutting the answer itself.
8. Remove process narration lines (`I will run`, `now I ran`, `I have enough`) from final output.
9. Keep exactly one disclaimer block in compact answers.
10. If a case is central to the conclusion, verify at least one official case source link (court or OTA) is cited.
11. Confirm the sweep query years match the freshness/as-of year shown in `Sources`.

## California Nonresident Service-Income Rules

Do not use one generic service-income rule.

Classify the taxpayer first.

### W-2 employees

For nonresident W-2 employees, California wage sourcing generally turns on where the employee physically performs services, subject to special rules for:

- deferred compensation
- equity compensation
- bonuses
- part-year residency
- California workdays

Do not apply sole proprietor customer-benefit rules to W-2 wages.

### Independent contractors / sole proprietors

For nonresident independent contractors and sole proprietors, current FTB practical guidance may use a customer-benefit approach.

Under that guidance, FTB may focus on where the customer receives the benefit of the service rather than where the contractor physically performs the work.

Do not treat FTB practical guidance as the end of the analysis. Check whether statutes, regulations, OTA precedential opinions, published cases, or other current authority support, limit, or conflict with that agency position.

Use cautious framing:

> FTB may assert California-source income if California customers receive the benefit of the services in California, but the strength of that position depends on the applicable statutes, regulations, current case law, taxpayer role, business structure, facts, and apportionment theory.

Do not say the income is definitely taxable or definitely non-taxable unless current controlling authority supports that level of certainty.

Do not reduce the rule to either:

- `California clients automatically create California-source income`, or
- `out-of-state physical performance automatically eliminates California-source income`.

### Pass-through owners

For partners, S corporation shareholders, and LLC members, analyze entity-level California-source income and owner-level reporting separately.

Do not apply sole proprietor rules automatically to K-1 income.

### Apportioning businesses

If a trade or business has income inside and outside California, consider allocation, apportionment, Schedule R, and market-assignment rules.

Do not assume that market-assignment rules directly resolve the nonresident individual sourcing question without explaining the statutory or regulatory path that makes those rules relevant.

## Required Distinctions

Always separate:

- residency vs source income
- employee vs contractor vs sole proprietor
- sole proprietor income vs pass-through income
- agency position vs binding law
- practical guidance vs controlling authority
- legal conclusion vs filing mechanics
- current authority vs older authority
- holding vs dicta
- practical audit risk vs court-strength position
- customer location vs customer-benefit location
- taxability conclusion vs filing-risk conclusion
- California business presence vs California customer base

## Answer Contract

### Bottom Line

Answer directly in 1-2 sentences.

Use risk-based language when authority is mixed:

- `Possibly`
- `FTB may assert`
- `The taxpayer may have arguments`
- `The result depends on facts and current authority`
- `This is a filing-risk question, not a simple yes/no question`

Avoid categorical wording unless the cited authority supports it.

### Quick Read (3 Key Points)

List exactly 3 bullets:

- what FTB is likely to assert
- what taxpayer-side argument exists
- what single fact most changes the outcome

Each bullet should be one short sentence.
Keep each bullet to one line where possible.

### What This Means for You

Explain practical impact in plain language.

Include:

- likely filing posture
- what outcome is uncertain
- what records matter most

In `Compact` mode, this section is optional.

### What To Do Now

Provide a short action checklist (3-5 bullets).

Use concrete actions and documents.

Example:

- confirm residency break evidence
- gather work-location records
- decide filing posture with CPA/tax attorney
- prepare disclosure/protective position if risk is high

### Why

Explain the controlling distinction in plain English.

For California nonresident sourcing questions, usually explain:

- taxpayer role
- residency vs source income
- agency position
- current directly relevant higher authority, if any
- any conflict between agency guidance and higher authority
- why the answer is risk-based if authorities are mixed

In `Compact` mode, keep `Why` to 1 short paragraph or omit it.

### Authorities

List only the most relevant authorities. Label each authority.

Do not over-cite.

When authorities conflict, order them by legal weight and explain the conflict.

Do not present forms, publications, agency webpages, FAQs, or scenario guidance as binding law.

Do not cite FTB Publication 1005 for service-income sourcing unless the issue involves pensions or annuities.

For non-memo answers, do not use large authority tables unless they materially improve clarity.
In `Compact` mode, prefer inline citations over a full table.

### Application

Apply the facts. State assumptions and uncertainty.

For non-memo answers, fold this into `What This Means for You` unless a separate `Application` section is needed.

For sourcing issues, identify:

- where work was performed
- where customers received the benefit
- whether customer location differs from benefit location
- whether the taxpayer has California business presence
- whether the income is sole proprietor, employee, entity, pass-through, intangible, or real-property income
- whether the issue involves allocation, apportionment, or market assignment

### Filing Guidance

Mention forms, schedules, recordkeeping, filing thresholds, estimated taxes, disclosures, withholding, refund claims, or protective claims only as practical guidance.

For non-memo answers, present this as `What To Do Now`.

Do not present filing mechanics as legal authority.

Do not make broad refund, penalty, withholding, or statute-of-limitations claims without checking procedural rules and tax-year facts.

### Risk

Give a brief risk level: `low`, `medium`, or `high`.

Explain what would change the answer.

Use language such as:

- `FTB may assert this position, but taxpayer-side authority exists.`
- `The agency position is clear, but the court-strength position may be disputed.`
- `This is a filing-risk question, not a simple yes/no question.`
- `A published court decision may limit the agency theory, but may not resolve every alternative theory.`

Avoid:

- `clearly taxable`
- `clearly not taxable`
- `no risk`
- `FTB cannot tax this`
- `FTB will definitely win`

unless the cited authority actually supports that level of certainty.

Include one sentence titled `What would change this answer:` and list the top 1-3 swing facts.
In `Compact` mode, keep `Risk` to 2-4 bullets.

### Sources

Provide official or reliable links for cited authorities.

For each source, include:

- citation
- authority label
- source type
- URL
- why it matters

For `Compact` mode:

- provide 3-4 sources max
- one short line each
- include at least 2 official links among those sources (statute/regulation, court, or agency)

For date-sensitive questions, also include:

- freshness check date (`YYYY-MM-DD`)
- recent case-law sweep log (`query -> source checked -> result`)

In `Compact` mode, limit sweep log to the top 2-3 queries.
In `Compact` mode, keep sweep log to 2 queries unless user asks for detailed research trace.
For time-sensitive legal disputes, the first sweep-log line should be the official court-source check.

For subsection-level claims, also include:

- pinpoint citation (`section/subsection`)
- one-line verification note (`text confirmed` or `not confirmed; treated as lead`)

## Output Rules

- Do not invent authorities.
- Do not cite authority without checking fit.
- Do not call practical guidance binding law.
- Do not treat nonprecedential material as controlling.
- Do not treat OTA precedential opinions as stronger than contrary published appellate authority.
- Do not give categorical answers when authority is mixed.
- Do not overread cases.
- Do not ignore recent directly relevant authority.
- Do not say no published authority exists without checking current cases.
- Do not say no newer authority exists without a date-stamped recent case-law sweep.
- Do not say no published appellate authority exists if the query window does not include the current year.
- Do not use a sweep year inconsistent with the stated freshness/as-of date.
- Do not show both `freshness check date` and a separate sweep year field; derive year internally from the date.
- Do not cite subsection-level rules without verifying the subsection text and taxpayer-role fit.
- Do not use a year-specific form PDF as the only support for current regulation text.
- Do not bury the answer under the authority stack.
- Do not let legal detail crowd out the opening plain-language answer.
- Do not use wall-of-text paragraphs when a short bullet list is clearer.
- Do not exceed compact length limits unless the user asked for detail.
- Do not repeat the same disclaimer sentence more than once.
- Do not include process narration in final answers.
- Do not use rhetorical emphasis words to describe legal developments.
- Do not use more than one full question-type template in a single answer.
- Do not place more than 2 explanatory paragraphs before actionable guidance.
- Do not treat an agency position as the final answer when published authority may limit that position.
- Do not treat a single case as resolving all similar fact patterns unless the holding actually does so.
- Do not use over-strong appellate effect language (for example `directly overruled`) unless the opinion explicitly says so.
- Do not base a key legal conclusion on commentary-only links when an official case or agency source exists.
- Do not cite a case as central authority without at least one official case link.
- Do not use examples as hardcoded answers.
- Do not cite FTB Publication 1005 unless pensions or annuities are involved.
- Do not label RTC section 25136 as a regulation.
- Do not say RTC section 25136 alone directly taxes nonresident sole proprietors.
- Do not cite Valentino for a broad sole proprietor physical-performance rule.

## Required Disclaimer Snippets

Use when applicable.

If residency is relevant:

> Residency and domicile are separate from source-income analysis. A taxpayer who remains a California resident may be taxed on worldwide income regardless of the source-income result.

If only weak authority exists:

> Current support is nonprecedential or practical guidance only; this is a research lead, not controlling authority for a filing position.

If payroll classification appears:

> This is a payroll tax/compliance research draft. Worker classification may also require employment-law review.

If agency guidance conflicts with higher authority:

> The agency position is relevant to filing and audit risk, but it may not control if higher or more directly applicable authority limits that theory.

If authority is mixed:

> This is a filing-risk question, not a simple yes/no question. The answer depends on facts, current authority, and how the agency theory applies to this taxpayer.

If tooling or access limits prevent a current-case sweep:

> I could not fully verify recent published cases in this run. Treat this as a preliminary research draft until current case status is confirmed.

## Resource Usage

Read before finalizing answers:

- `references/authority-framework.md`

Use examples only as examples. Do not treat them as hardcoded answers.

When the issue is current, litigation-prone, or depends on agency guidance, verify whether directly relevant published cases or precedential decisions have changed the analysis before finalizing.
